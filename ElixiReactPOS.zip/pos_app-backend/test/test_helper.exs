ExUnit.start()
Ecto.Adapters.SQL.Sandbox.mode(PosApp.Repo, :manual)
