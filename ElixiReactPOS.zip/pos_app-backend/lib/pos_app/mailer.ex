defmodule PosApp.Mailer do
  use Swoosh.Mailer, otp_app: :pos_app
end
